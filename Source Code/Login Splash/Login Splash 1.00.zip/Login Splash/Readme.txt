Login Splash 1.0.1

Usage: <filename.exe> <heading> <message.rtf> where "heading" is the Title string to be displayed on the main form and "message.rtf" is the path of the required input message file for the splash screen to display.